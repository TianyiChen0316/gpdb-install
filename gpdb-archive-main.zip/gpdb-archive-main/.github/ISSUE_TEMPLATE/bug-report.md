---
name: "\U0001F41B Bug Report"
about: As a user, I want to report a bug.
labels: "type: bug"
---

## Bug Report

### Greenplum version or build

### OS version and uname -a

### autoconf options used ( config.status --config )

### Installation information ( pg_config )

### Expected behavior

### Actual behavior

### Step to reproduce the behavior
